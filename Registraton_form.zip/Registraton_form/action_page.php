







<?php
include'db.php';
$name=$_POST['fname'].$_POST['lname'];
$mothername=$_POST['mfname'].$_POST['mlname'];
$fathername=$_POST['ffname'].$_POST['flname'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$gender=$_POST['r1'];
$nationality=$_POST['nation'].'/'.$gender;
$country=$_POST['country'];
$city=$_POST['city'];
$dob=$_POST['dob'];
$adress=$_POST['adress'];

$Educationa_details1='12TH'.','.'INSTITUTE:'.$_POST['innametwv'].','.'university/board:'.$_POST['university/board'].','.'adreess:'.$_POST['twvcity'].','.$_POST['twvstate'].','.$_POST['twvcountry'].','.'field:'.$_POST['twvcourse'].','.'passing_year:'.$_POST['twvpassing'].'mark:'.$_POST["twvmark"];

$Educationa_details2='10TH'.','.'INSTITUTE:'.$_POST['teniname'].','.'university/board:'.$_POST['tenboard'].','.'adreess:'.$_POST['tencity'].','.$_POST['tensta'].','.$_POST['tencountry'].','.'field:'.$_POST['tencourse'].','.'passing_year:'.$_POST['tenpassing'].'mark:'.$_POST["tenmark"];

$Educationa_details3='Graduation'.','.'INSTITUTE:'.$_POST['inamegraduate'].','.'university/board:'.$_POST['graduationboard'].','.'adreess:'.$_POST['graduationcity'].','.$_POST['graduationstate'].','.$_POST['graduationcountry'].','.'field:'.$_POST['graduationcourse'].','.'passing_year:'.$_POST['graduationpassing'].'mark:'.$_POST["gradmark"];




$sql = "INSERT INTO student(name,email,mobileno,father,mother,date_of_birth, nationality_gender,address,country	,Educationa_details1,Educationa_details2,Educationa_details3) 
			VALUES ( '$name' , '$email','$phone',  '$fathername','$mothername' ,'$dob','$nationality','$adress','$country','$Educationa_details1','$Educationa_details2','$Educationa_details3')";
			if ($conn->query($sql) === TRUE) {
  echo "<body style='background-color:skyblue''><p style='margin-top:37px;color:white;border:12px solid black;background-image:radial-gradient(green,black);font-size:35px;padding:40px;border-radius:34px;box-shadow:12px 12px 12px  grey;font-family:cursive;' align=center>Personal-detalis submitted<br><br>Educational_details submitted<br><br>";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$target_file = basename($_FILES["file"]["name"]);
$target_file2 = basename($_FILES["file2"]["name"]);
$target_file3 = basename($_FILES["file3"]["name"]);
$target_file4 = basename($_FILES["file4"]["name"]);
 $uploads_dir = "/multi_step_registraton_form/uploads";
   
   move_uploaded_file("$target_file", "$uploads_dir/$target_file ");
$sql1 = "INSERT INTO documents(email,photo,10th,12th,semester_result) 
			VALUES ('$email','$target_file','$target_file2','$target_file3','$target_file4')";
	if ($conn->query($sql1) === TRUE) {
  echo "Document uploded successfully</p>";
} else 


{
  echo"Document not uploaded successfully ";
}

?>


